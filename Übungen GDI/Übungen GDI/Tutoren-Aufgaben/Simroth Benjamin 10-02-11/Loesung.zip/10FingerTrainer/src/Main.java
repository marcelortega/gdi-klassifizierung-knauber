import static gdi.MakeItSimple.*;

/**
 * Aufgabe 4
 * 10 Finger Tipptrainer
 */
public class Main {

    // Mögliche Probleme: Definition darf nicht in einer Funktion sein
    static String[] eingabeInhalte = {"jfff ff jfj jff jjfj ffj fff jff fjfj jff jjff fjff",
        "dk kdd kkk ddkdk dkd kdkk kkkkd kdd ddkk dddkd ddk"};
    static char aktuellerBuchstabe;
    static int falscheBuchstaben = 0,  insgesamtEingaben = 0,  insgesamtFehler = 0,  fehlerQuote;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for (int i = 0; i < eingabeInhalte.length; i++) {
            println(eingabeInhalte[i]);
            for (int j = 0; j < strLen(eingabeInhalte[i]); j++) {
                aktuellerBuchstabe = readChar();
                // Jeden eingegebene Buchstaben asychron prüfen (da auf ENTER gewartet wird)
                if (strCharAt(eingabeInhalte[i], j) != aktuellerBuchstabe) {
                    falscheBuchstaben++;
                }


            }
            // Das ENTER aus dem Puffer weglesen
            readChar();
            
            println("Sie haben bei " + strLen(eingabeInhalte[i]) + " Eingaben " + falscheBuchstaben + " Fehler gemacht");
            insgesamtFehler += falscheBuchstaben;
            falscheBuchstaben = 0;
            insgesamtEingaben += strLen(eingabeInhalte[i]);

        }
        fehlerQuote = (int) ((insgesamtFehler * 1.0 / insgesamtEingaben) * 100);
        println("Bei insgesamt " + insgesamtEingaben + " Zeichen haben Sie " + insgesamtFehler + " Fehler gemacht.");
        println("Ihre Fehlerquote liegt bei " + fehlerQuote + "%");
    }
}
