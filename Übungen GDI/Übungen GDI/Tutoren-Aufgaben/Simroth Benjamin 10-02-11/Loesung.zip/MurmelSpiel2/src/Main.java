
import java.util.Random;
import static gdi.MakeItSimple.*;

/**
 * Aufgabe 2
 * Murmelspiel Erweitert durch Computergegenspieler
 */
public class Main {

    //static final int multiplikator = 3; // Aufgabe 1

    // Erweiterung in Aufgabe 3
    static Random r = new Random();
    // Achtung der Multiplikator kann den Wert 0 annehmen
    static final int multiplikator = r.nextInt(2) + 1;
    static int anzahlSpieler = 2,  anzahlMurmeln = 0,  aktuellerSpieler = 1;
    static int genommeMurmeln,  murmelnDieGenommenWerdenKoennen;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {


        anzahlMurmeln = 3 * multiplikator;

        println("Es befinden sich " + anzahlMurmeln + " im Topf.");

        // Solange noch Murmeln im Topf sind
        while (anzahlMurmeln > 0) {

            println();
            do {
                // Es dürfen nur zwischen 1 und 3 Murmeln genommen werden
                if (anzahlMurmeln < 3) {
                    murmelnDieGenommenWerdenKoennen = anzahlMurmeln;
                } else {
                    murmelnDieGenommenWerdenKoennen = 3;
                }
                print("Spieler " + aktuellerSpieler + ": Wieviel Murmeln möchten Sie nehmen? (1-" + murmelnDieGenommenWerdenKoennen + ") ");
                if (aktuellerSpieler == 1) {
                    // KI - unwahrscheinlich genau die 1. zu treffen, daher statische Behandelung
                    if (murmelnDieGenommenWerdenKoennen == 1) {
                        genommeMurmeln = 1;
                    } else {
                        genommeMurmeln = r.nextInt(murmelnDieGenommenWerdenKoennen);
                    }
                    println(genommeMurmeln);
                } else {
                    genommeMurmeln = readInt();
                }
            } while (genommeMurmeln > 3 || genommeMurmeln < 1 || genommeMurmeln > anzahlMurmeln);

            anzahlMurmeln = anzahlMurmeln - genommeMurmeln;

            // Wenn der Murmeltopf leer ist, Spiel abbrechen und den Verlierer anzeigen
            if (anzahlMurmeln == 0) {
                break;
            }

            /*
             * Wenn der letzte Spieler dran war, wieder zum Ersten springen
             * ansonsten zum nächsten Spieler wechseln
             */
            if (anzahlSpieler == aktuellerSpieler) {
                aktuellerSpieler = 1;
            } else {
                aktuellerSpieler++;
            }

        }
        println("\nSpieler " + aktuellerSpieler + " hat verloren.");


    }
}
